module.exports = {
    IMAGE_MIMETYPES: [
        'image/jpeg',
        'image/png'
    ],

    IMAGE_MAX_SIZE: 3 * 1024 * 1024,    //3 MB
}