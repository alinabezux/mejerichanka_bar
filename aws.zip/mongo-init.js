db.createUser(
    {
        user: 'alina',
        pwd: 'TnHqc5KNI3bqGkxU',
        roles: [
            {
                role: 'readWrite',
                db: 'mejerichanka'
            }
        ]
    }
)